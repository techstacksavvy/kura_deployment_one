<img src="https://github.com/kura-labs-org/kuralabs_deployment_1/blob/main/Kuralogo.png">
<h1 align="center">kuralabs_deployment_1<h1> 


Learn how to create a full CI/CD pipeline to visibly see and configure each stage of the pipeline.

## Deployment Document Link:
-  Link to instructions: https://github.com/kura-labs-org/kuralabs_deployment_1/blob/main/Deployment-1_Assignment%20(1).pdf
